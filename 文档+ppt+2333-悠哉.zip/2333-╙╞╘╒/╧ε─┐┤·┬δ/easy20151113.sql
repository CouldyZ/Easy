/*
SQLyog 企业版 - MySQL GUI v8.14 
MySQL - 5.1.49-community : Database - easy
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`easy` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `easy`;

/*Table structure for table `act` */

DROP TABLE IF EXISTS `act`;

CREATE TABLE `act` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `create_date` datetime NOT NULL,
  `theme` varchar(64) NOT NULL,
  `account` int(11) NOT NULL,
  `days` int(11) NOT NULL,
  `pay` float NOT NULL,
  `states` char(1) NOT NULL,
  `contents` varchar(512) NOT NULL,
  `start_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_1` (`users_id`),
  CONSTRAINT `FK_act_user` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

/*Data for the table `act` */

insert  into `act`(`id`,`users_id`,`create_date`,`theme`,`account`,`days`,`pay`,`states`,`contents`,`start_date`) values (1,1,'2015-10-19 08:20:00','12级同学聚会',50,1,100,'4','22号晚上6点在东门蜀味源','2015-10-22 08:20:00'),(2,2,'2015-10-20 09:05:00','转学生欢迎会',50,2,100,'3','23号晚上新宿','2015-10-23 09:05:00'),(3,3,'2015-10-21 09:50:00','挂科大趴',50,3,100,'2','24号晚上梅园','2015-10-24 09:50:00'),(4,4,'2015-10-26 10:30:00','天文学爱好者茶会',50,4,100,'1','28号早八点数计','2015-10-28 10:30:00'),(5,5,'2015-10-26 11:15:00','草莓派对',20,5,50,'1','28号下午三点麦乐迪','2015-10-28 11:15:00'),(6,6,'2015-10-26 12:00:00','芒果派对',30,6,40,'1','28号中午未名湖畔','2015-10-28 12:00:00'),(7,1,'2015-11-20 12:45:00','装逼是如何炼成的？！',15,1,250,'1','晚上十点勤人坡','2015-11-25 12:45:00'),(8,1,'2015-11-21 13:30:00','冲矢昴和刀疤男到底谁才是真正的赤井秀一？！',27,1,15,'1','借会议室一用，自带零食','2015-11-22 12:30:00'),(9,1,'2015-11-22 14:15:00','COSPLAY交流会',20,1,150,'1','人文中心，19:00','2015-11-23 13:15:00'),(10,2,'2015-11-23 15:00:00','舞林大会',24,1,50,'1','聂耳剧场，19:00','2015-11-24 14:00:00'),(11,2,'2015-11-24 15:45:00','我的奇葩室友',8,1,10,'1','魔锅传奇外面的小餐厅，19:00','2015-11-25 14:45:00'),(12,2,'2015-11-25 16:40:00','桃花源骑车行',4,1,30,'1','国际交流中心公交站，8:00','2015-11-26 15:30:00'),(13,4,'2015-11-12 20:58:58','ceshi theme',100,4,200,'1','text content','2015-04-04 00:00:00'),(14,4,'2015-11-12 21:10:52','ceshi  21:20',23,4,1000,'1','content ','2015-06-07 00:00:00');

/*Table structure for table `collects` */

DROP TABLE IF EXISTS `collects`;

CREATE TABLE `collects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `posts_id` int(11) NOT NULL,
  `dates` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_1` (`users_id`),
  KEY `index_2` (`posts_id`),
  CONSTRAINT `FK_collect_post` FOREIGN KEY (`posts_id`) REFERENCES `posts` (`id`),
  CONSTRAINT `FK_collect_user` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

/*Data for the table `collects` */

insert  into `collects`(`id`,`users_id`,`posts_id`,`dates`) values (2,1,2,'2015-11-04 08:50:00'),(8,1,8,'2015-11-12 11:06:26'),(9,1,5,'2015-11-12 11:06:48'),(11,1,3,'2015-11-12 11:42:47'),(13,4,5,'2015-11-12 13:13:11'),(16,4,9,'2015-11-12 21:30:02'),(17,7,1,'2015-11-13 11:10:28');

/*Table structure for table `comments` */

DROP TABLE IF EXISTS `comments`;

CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `dates` datetime NOT NULL,
  `contents` varchar(128) NOT NULL,
  `posts_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_1` (`users_id`),
  KEY `index_2` (`posts_id`),
  CONSTRAINT `FK_comment_post` FOREIGN KEY (`posts_id`) REFERENCES `posts` (`id`),
  CONSTRAINT `FK_comment_user` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

/*Data for the table `comments` */

insert  into `comments`(`id`,`users_id`,`dates`,`contents`,`posts_id`) values (1,4,'2015-11-04 10:30:23','顶',3),(2,3,'2015-11-04 11:55:00','然而，毕业了，然后就没有然后了',6),(4,4,'2015-11-12 10:11:38','java 关键字有哪些呢？',1),(5,2,'2015-11-12 10:17:26','人呢？',4),(6,4,'2015-11-12 10:23:19','public',1),(7,3,'2015-11-12 10:24:45','还有protected',1),(8,4,'2015-11-12 19:45:16','nice',2),(9,4,'2015-11-12 19:45:32','ios 发展前景不错呢',2),(10,4,'2015-11-12 19:48:07','android 最新的技术有哪些？',1),(11,4,'2015-11-12 20:04:42','very nice',2),(12,4,'2015-11-12 20:07:21','i think so',2),(13,7,'2015-11-13 11:10:05','Android',1);

/*Table structure for table `goods` */

DROP TABLE IF EXISTS `goods`;

CREATE TABLE `goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `price` float NOT NULL,
  `deposit` float NOT NULL,
  `img_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_1` (`shop_id`),
  KEY `index_2` (`img_id`),
  CONSTRAINT `FK_goods_image` FOREIGN KEY (`img_id`) REFERENCES `image` (`id`),
  CONSTRAINT `FK_goods_shop` FOREIGN KEY (`shop_id`) REFERENCES `shop` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

/*Data for the table `goods` */

insert  into `goods`(`id`,`name`,`shop_id`,`price`,`deposit`,`img_id`) values (1,'面包',1,42.8,0.1,6),(2,'牛奶',1,29.9,0.1,7),(3,'黑人牙膏',2,28,0.1,8),(4,'牛肉',1,30,0.1,9),(5,'碧根果',1,41,0.1,10),(6,'饼干',1,9,0.1,11),(7,'彩虹糖',1,5,0.1,12),(8,'糖果',1,4,0.1,13),(9,'豆腐',1,2,0.1,14),(10,'农夫果园',2,3.2,0.1,15),(11,'水果饮料',2,2.5,0.1,16),(12,'吸尘器',2,86,0.1,17),(13,'保鲜膜',2,6,0.1,18),(14,'夏威夷果',2,32,0.1,19),(15,'大米',2,4,0.1,20),(16,'沙琪玛',2,5.5,0.1,21),(17,'茶壶',2,8,0.1,22),(18,'洁厕灵',2,11,0.1,23),(19,' 洗衣液',2,13,0.1,24),(20,'纸巾',2,5.8,0.1,25);

/*Table structure for table `image` */

DROP TABLE IF EXISTS `image`;

CREATE TABLE `image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `urls` varchar(128) NOT NULL,
  `users_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_1` (`users_id`),
  CONSTRAINT `FK_reference_23` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

/*Data for the table `image` */

insert  into `image`(`id`,`urls`,`users_id`) values (1,'/projectPicture/thhh/image/avatar/avatar1.png',NULL),(2,'/projectPicture/thhh/image/avatar/avatar2.png',NULL),(4,'/projectPicture/thhh/image/shop/baijia.png',NULL),(5,'/projectPicture/thhh/image/shop/runfu.png',NULL),(6,'/projectPicture/thhh/image/goods/bread.png',NULL),(7,'/projectPicture/thhh/image/goods/milk.png',NULL),(8,'/projectPicture/thhh/image/goods/toothpaste.png',NULL),(9,'/projectPicture/thhh/image/goods/beef.png',NULL),(10,'/projectPicture/thhh/image/goods/bigenguo.png',NULL),(11,'/projectPicture/thhh/image/goods/binggan.png',NULL),(12,'/projectPicture/thhh/image/goods/candy2.png',NULL),(13,'/projectPicture/thhh/image/goods/candy.png',NULL),(14,'/projectPicture/thhh/image/goods/doufu.png',NULL),(15,'/projectPicture/thhh/image/goods/drink2.png',NULL),(16,'/projectPicture/thhh/image/goods/drink.png',NULL),(17,'/projectPicture/thhh/image/goods/fei.png',NULL),(18,'/projectPicture/thhh/image/goods/mo.png',NULL),(19,'/projectPicture/thhh/image/goods/nut.png',NULL),(20,'/projectPicture/thhh/image/goods/rice.png',NULL),(21,'/projectPicture/thhh/image/goods/saqima.png',NULL),(22,'/projectPicture/thhh/image/goods/tea.png',NULL),(23,'/projectPicture/thhh/image/goods/wash2.png',NULL),(24,'/projectPicture/thhh/image/goods/wash.png',NULL),(25,'/projectPicture/thhh/image/goods/zhi.png',NULL),(31,'/projectPicture/thhh/image/avatar/avatar3.png',NULL),(32,'/projectPicture/thhh/image/avatar/avatar4.png',NULL),(33,'/projectPicture/thhh/image/avatar/avatar5.png',NULL),(34,'/projectPicture/thhh/image/avatar/avatar6.png',NULL),(35,'/projectPicture/thhh/image/avatar/avatar7.png',NULL),(36,'/projectPicture/thhh/image/posts/posts1.png',NULL),(37,'/projectPicture/thhh/image/posts/posts2.png',NULL),(38,'/projectPicture/thhh/image/posts/posts3.png',NULL),(39,'/projectPicture/thhh/image/posts/posts4.png',NULL),(40,'/projectPicture/thhh/image/posts/posts5.png',NULL),(41,'/projectPicture/thhh/image/posts/posts6.png',NULL),(42,'/projectPicture/thhh/image/posts/posts7.png',NULL),(43,'/projectPicture/thhh/image/posts/posts8.png',NULL);

/*Table structure for table `likes` */

DROP TABLE IF EXISTS `likes`;

CREATE TABLE `likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `posts_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_1` (`posts_id`),
  KEY `index_2` (`users_id`),
  CONSTRAINT `FK_likes_post` FOREIGN KEY (`posts_id`) REFERENCES `posts` (`id`),
  CONSTRAINT `FK_likes_user` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

/*Data for the table `likes` */

insert  into `likes`(`id`,`posts_id`,`users_id`) values (1,1,2),(2,1,3),(3,3,1),(4,4,1),(10,8,4),(11,1,7);

/*Table structure for table `orderdetail` */

DROP TABLE IF EXISTS `orderdetail`;

CREATE TABLE `orderdetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) NOT NULL,
  `goods_id` int(11) NOT NULL,
  `account` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `all_deposit` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_1` (`orders_id`),
  KEY `index_2` (`goods_id`),
  CONSTRAINT `FK_orderdetail_goods` FOREIGN KEY (`goods_id`) REFERENCES `goods` (`id`),
  CONSTRAINT `FK_orderdetail_order` FOREIGN KEY (`orders_id`) REFERENCES `orders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

/*Data for the table `orderdetail` */

insert  into `orderdetail`(`id`,`orders_id`,`goods_id`,`account`,`amount`,`all_deposit`) values (1,1,1,1,'42.80',0.1),(2,1,2,1,'29.90',0.1),(3,3,4,1,'30.00',3),(4,3,1,1,'42.80',4.28),(5,3,2,1,'29.90',2.99),(6,4,6,1,'9.00',0.9),(7,4,5,1,'41.00',4.1),(8,5,4,1,'30.00',3),(9,5,6,1,'9.00',0.9),(10,6,1,1,'42.80',4.28),(11,6,2,1,'29.90',2.99),(12,8,4,1,'30.00',3),(13,8,1,1,'42.80',4.28);

/*Table structure for table `orders` */

DROP TABLE IF EXISTS `orders`;

CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `dates` datetime NOT NULL,
  `states` char(1) NOT NULL,
  `take` varchar(32) NOT NULL,
  `shop_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_1` (`users_id`),
  KEY `index_2` (`shop_id`),
  CONSTRAINT `FK_orders_shop` FOREIGN KEY (`shop_id`) REFERENCES `shop` (`id`),
  CONSTRAINT `FK_orders_user` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

/*Data for the table `orders` */

insert  into `orders`(`id`,`users_id`,`dates`,`states`,`take`,`shop_id`) values (1,1,'2015-11-04 09:17:00','1','16:00-18:00',1),(3,2,'2015-11-10 20:15:10','1','14:00-17:00',1),(4,4,'2015-11-12 11:56:58','1','12:00 - 14:00',1),(5,4,'2015-11-12 13:43:22','1','12:00 - 14:00',1),(6,4,'2015-11-12 20:43:12','1','12:00 - 14:00',1),(8,7,'2015-11-13 11:07:57','1','12:00 - 14:00',1);

/*Table structure for table `partici` */

DROP TABLE IF EXISTS `partici`;

CREATE TABLE `partici` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `act_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_1` (`users_id`),
  KEY `index_2` (`act_id`),
  CONSTRAINT `FK_partici_act` FOREIGN KEY (`act_id`) REFERENCES `act` (`id`),
  CONSTRAINT `FK_partici_user` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

/*Data for the table `partici` */

insert  into `partici`(`id`,`users_id`,`act_id`) values (1,1,1),(2,2,2),(3,3,3),(4,4,4),(5,5,5),(6,6,6),(7,1,6),(8,1,7),(9,1,8),(10,1,9),(11,2,10),(12,2,11),(13,2,12),(14,3,7),(15,3,8),(16,4,10),(17,4,11),(18,1,12),(19,2,9),(20,4,8),(21,4,13),(22,4,14),(23,7,12);

/*Table structure for table `posts` */

DROP TABLE IF EXISTS `posts`;

CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `dates` datetime NOT NULL,
  `img_id` int(11) DEFAULT NULL,
  `contents` varchar(1024) NOT NULL,
  `latest` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_1` (`users_id`),
  KEY `index_2` (`img_id`),
  CONSTRAINT `FK_post_user` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`),
  CONSTRAINT `FK_reference_22` FOREIGN KEY (`img_id`) REFERENCES `image` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

/*Data for the table `posts` */

insert  into `posts`(`id`,`users_id`,`dates`,`img_id`,`contents`,`latest`) values (1,1,'2015-11-11 02:03:00',36,'java技术交流贴',NULL),(2,3,'2015-11-10 23:07:00',37,'ios开发技术',NULL),(3,2,'2015-11-03 20:07:00',38,'android交流贴',NULL),(4,2,'2015-11-04 16:37:00',39,'ssh教程',NULL),(5,1,'2015-11-10 16:59:11',40,'Spring讨论',NULL),(6,1,'2015-11-10 17:00:45',41,'要毕业了，来谈谈感想',NULL),(8,1,'2015-11-10 17:04:27',42,'有点炫，是吧',NULL),(9,4,'2015-11-12 13:33:43',NULL,'说说你的双十一',NULL);

/*Table structure for table `report` */

DROP TABLE IF EXISTS `report`;

CREATE TABLE `report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `act_id` int(11) NOT NULL,
  `dates` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_1` (`users_id`),
  KEY `index_2` (`act_id`),
  CONSTRAINT `FK_report_act` FOREIGN KEY (`act_id`) REFERENCES `act` (`id`),
  CONSTRAINT `FK_report_user` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `report` */

insert  into `report`(`id`,`users_id`,`act_id`,`dates`) values (1,4,1,'2015-10-20 13:35:00'),(2,4,2,'2015-10-21 21:04:00'),(3,4,3,'2015-11-01 18:06:00'),(4,6,1,'2015-11-03 17:40:00'),(5,4,4,'2015-11-12 15:37:08');

/*Table structure for table `shop` */

DROP TABLE IF EXISTS `shop`;

CREATE TABLE `shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `address` varchar(128) NOT NULL,
  `phone` varchar(32) NOT NULL,
  `shortcut` varchar(128) NOT NULL,
  `img_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_1` (`img_id`),
  CONSTRAINT `FK_shop_image` FOREIGN KEY (`img_id`) REFERENCES `image` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `shop` */

insert  into `shop`(`id`,`name`,`address`,`phone`,`shortcut`,`img_id`) values (1,'百佳超市','黄金校区人文科技10号','07978393111','致力于为大家提供最全的生活服务',4),(2,'润福超市','黄金校区尚学大道21号','07978393222','这里的东西都是物美价廉的，欢迎同学们前来选购',5);

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `pwd` varchar(64) NOT NULL,
  `nickname` varchar(64) DEFAULT NULL,
  `img_id` int(11) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `numbers` varchar(64) DEFAULT NULL,
  `depart` varchar(64) DEFAULT NULL,
  `tname` varchar(64) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `rp` int(11) NOT NULL DEFAULT '70',
  PRIMARY KEY (`id`),
  KEY `index_1` (`img_id`),
  CONSTRAINT `FK_user_image` FOREIGN KEY (`img_id`) REFERENCES `image` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `users` */

insert  into `users`(`id`,`name`,`pwd`,`nickname`,`img_id`,`email`,`numbers`,`depart`,`tname`,`gender`,`rp`) values (1,'王梦','12345678','小王',1,'xiaowang@163.com','120703000','数学与计算机科学学院','王五','1',70),(2,'张寒','12345678','小张',2,'xiaozhang@qq.com','120703111','物理与电子科学学院','张三','1',69),(3,'张霖','12345678','小小',32,'xiaoxiao@163.com','120703555','外院','张霖','1',69),(4,'smithes','12345678','小红',31,'xiaohong@fox.mail','120703444','商学院','韩红','0',69),(5,'join','12312378','微子',33,'xuwei@fox.mail','120703034','数计','许巍','0',70),(6,'nancy','11122278','梦子',34,'meng@fox.mail','120700000','美院','孟子','0',70),(7,'cindyness','12345678','Cindy',NULL,NULL,NULL,NULL,'Cindy',NULL,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
